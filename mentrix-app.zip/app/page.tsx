"use client"

import { useState } from "react"
import { AnimatePresence } from "framer-motion"
import Login from "@/components/auth/login"
import Register from "@/components/auth/register"
import Dashboard from "@/components/dashboard/dashboard"
import AssessmentForm from "@/components/assessment/assessment-form"
import AssessmentResults from "@/components/assessment/assessment-results"
import ArticlesList from "@/components/articles/articles-list"
import ArticleDetail from "@/components/articles/article-detail"
import AdminPanel from "@/components/admin/admin-panel"
import LandingPage from "@/components/landing/landing-page"
import { ThemeProvider } from "@/components/theme-provider"

export default function App() {
  const [currentPage, setCurrentPage] = useState("landing")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [currentArticle, setCurrentArticle] = useState(null)
  const [assessmentResult, setAssessmentResult] = useState(null)

  const handleLogin = (email, password) => {
    // In a real app, this would validate credentials against an API
    if (email && password) {
      setIsAuthenticated(true)
      setCurrentPage("dashboard")

      // Set admin status based on email (for demo purposes)
      if (email === "admin@mentrix.com") {
        setIsAdmin(true)
      }
    }
  }

  const handleRegister = (userData) => {
    // In a real app, this would send registration data to an API
    if (userData) {
      setIsAuthenticated(true)
      setCurrentPage("dashboard")
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setIsAdmin(false)
    setCurrentPage("landing")
  }

  const handleAssessmentComplete = (result) => {
    setAssessmentResult(result)
    setCurrentPage("results")
  }

  const handleViewArticle = (article) => {
    setCurrentArticle(article)
    setCurrentPage("article-detail")
  }

  const renderPage = () => {
    switch (currentPage) {
      case "landing":
        return <LandingPage onLogin={() => setCurrentPage("login")} onRegister={() => setCurrentPage("register")} />
      case "login":
        return <Login onLogin={handleLogin} onSwitchToRegister={() => setCurrentPage("register")} />
      case "register":
        return <Register onRegister={handleRegister} onSwitchToLogin={() => setCurrentPage("login")} />
      case "dashboard":
        return (
          <Dashboard
            onLogout={handleLogout}
            onStartAssessment={() => setCurrentPage("assessment")}
            onViewArticles={() => setCurrentPage("articles")}
            onViewAdmin={() => setCurrentPage("admin")}
            isAdmin={isAdmin}
          />
        )
      case "assessment":
        return <AssessmentForm onComplete={handleAssessmentComplete} onCancel={() => setCurrentPage("dashboard")} />
      case "results":
        return (
          <AssessmentResults
            result={assessmentResult}
            onBackToDashboard={() => setCurrentPage("dashboard")}
            onViewArticles={() => setCurrentPage("articles")}
          />
        )
      case "articles":
        return <ArticlesList onViewArticle={handleViewArticle} onBackToDashboard={() => setCurrentPage("dashboard")} />
      case "article-detail":
        return <ArticleDetail article={currentArticle} onBackToArticles={() => setCurrentPage("articles")} />
      case "admin":
        return <AdminPanel onBackToDashboard={() => setCurrentPage("dashboard")} />
      default:
        return <LandingPage onLogin={() => setCurrentPage("login")} onRegister={() => setCurrentPage("register")} />
    }
  }

  return (
    <ThemeProvider defaultTheme="dark" attribute="class">
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-950 to-gray-900 text-white">
        <AnimatePresence mode="wait">{renderPage()}</AnimatePresence>
      </div>
    </ThemeProvider>
  )
}

